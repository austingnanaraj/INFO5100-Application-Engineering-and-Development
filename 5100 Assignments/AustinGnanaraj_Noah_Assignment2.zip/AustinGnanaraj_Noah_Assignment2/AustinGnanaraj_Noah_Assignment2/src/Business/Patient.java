/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class Patient {
    private String patientFirstName,patientLastName,patientId,doctorName,preferredPharmacy; // declarations
    private int age;
    private VitalSignHistory vsh;

    public VitalSignHistory getVsh() { //getter and setter for vital sign history
        return vsh;
    }

    public void setVsh(VitalSignHistory vsh) {
        this.vsh = vsh;
    }

    
   
    public Patient(){
         vsh= new VitalSignHistory(); //  Vital Sign History referencing,  the object creation
    }
  
    

    public String getPatientFirstName() {
        return patientFirstName;
    }

    public void setPatientFirstName(String patientFirstName) {
        this.patientFirstName = patientFirstName;
    }

    public String getPatientLastName() {
        return patientLastName;
    }

    public void setPatientLastName(String patientLastName) {
        this.patientLastName = patientLastName;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getPreferredPharmacy() {
        return preferredPharmacy;
    }

    public void setPreferredPharmacy(String preferredPharmacy) {
        this.preferredPharmacy = preferredPharmacy;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    public String getVitalSign(VitalSign vs){
        String a;
        a= "No Status";
         if (this.age >= 1 && this.age <= 3) {
             
            if (vs.getRespiratoryRate()>= 20 && vs.getRespiratoryRate() <= 30
                    && vs.getHeartRate() >= 80 && vs.getHeartRate() <= 130
                    && vs.getSystolicBloodPressure() >= 80
                    && vs.getSystolicBloodPressure() <= 110
                    && vs.getWeightInPounds() >= 22
                    && vs.getWeightInPounds() <= 31) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }
        
        }
       if (this.age >= 4 && this.age <= 5) {
            if (vs.getRespiratoryRate() >= 20 && vs.getRespiratoryRate() <= 30
                    && vs.getHeartRate() >= 80 && vs.getHeartRate() <= 120
                    && vs.getSystolicBloodPressure() >= 80
                    && vs.getSystolicBloodPressure() <= 110
                    && vs.getWeightInPounds() >= 31
                    && vs.getWeightInPounds() >= 40) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }

        }
        if (this.age >= 6 && this.age <= 12) {
            if (vs.getRespiratoryRate() >= 20 && vs.getRespiratoryRate() <= 30
                    && vs.getHeartRate() >= 70 && vs.getHeartRate() <= 110
                    && vs.getSystolicBloodPressure() >= 80
                    && vs.getSystolicBloodPressure() <= 110
                    && vs.getWeightInPounds() >= 41
                    && vs.getWeightInPounds() >= 92) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }

        }
        if (this.age >= 13) {
            if (vs.getRespiratoryRate() >= 12 && vs.getRespiratoryRate() <= 20
                    && vs.getHeartRate() >= 55 && vs.getHeartRate() <= 105
                    && vs.getSystolicBloodPressure() >= 110
                    && vs.getSystolicBloodPressure() <= 120
                    && vs.getWeightInPounds() > 110) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;

            }

        }return a ;
} 
}
    

