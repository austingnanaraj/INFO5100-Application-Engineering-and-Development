/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class VitalSignHistory {
     private ArrayList<VitalSign> vsd;

 public VitalSignHistory(){ //Constructor to create a new ArrayList
       vsd=new ArrayList<>();
   }

    public ArrayList<VitalSign> getVsd() {
        return vsd;
    }

    public void setVsd(ArrayList<VitalSign> vsd) {
        this.vsd = vsd;
    }
 
 public VitalSign addVitalSign(){
     VitalSign vs= new VitalSign();
       vsd.add(vs);
       return vs;
 }
 public void removeVitalSign(VitalSign vs){
       vsd.remove(vs);    
   }
 }
