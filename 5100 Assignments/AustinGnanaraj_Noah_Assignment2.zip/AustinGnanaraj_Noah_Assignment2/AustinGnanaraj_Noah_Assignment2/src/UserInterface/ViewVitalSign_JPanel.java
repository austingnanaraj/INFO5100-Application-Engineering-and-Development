/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package UserInterface;

import Business.Patient;
import Business.VitalSign;
import Business.VitalSignHistory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author AustinGnanaraj
 */
public class ViewVitalSign_JPanel extends javax.swing.JPanel {
    private Patient p;
    private VitalSignHistory vsh;
    public ViewVitalSign_JPanel(Patient p) {
        initComponents();
        this.p=p;
        this.vsh=p.getVsh();
        populate();
    }
     public void populate(){  //JTable Population Code
        DefaultTableModel dtm=(DefaultTableModel)vitalSignjTable.getModel(); // setting the jtable to default property
        int rowcount  = vitalSignjTable.getRowCount(); //getting rowncount of JTable
        for (int i=rowcount - 1;i>=0;i--){ // For loop for removing the data by row wise
            dtm.removeRow(i);
        }
        for(VitalSign vs: vsh.getVsd()){ // using foreach vitalsign object to go through each and every value sequentially
       Object row[]= new Object[2]; // 2 columns of data
       row[0]=vs;
       row[1]=p.getVitalSign(vs);
       dtm.addRow(row);
    }
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        vitalSignjTable = new javax.swing.JTable();
        Remove_jButton2 = new javax.swing.JButton();
        View_jButton3 = new javax.swing.JButton();
        ViewRespiratoryRate_jLabel1 = new javax.swing.JLabel();
        ViewHeartRate_jLabel2 = new javax.swing.JLabel();
        ViewRespiratoryRate_jTextField1 = new javax.swing.JTextField();
        ViewHeartRate_jTextField2 = new javax.swing.JTextField();
        ViewSystolicBloodPressure_jLabel3 = new javax.swing.JLabel();
        ViewWeight_jLabel4 = new javax.swing.JLabel();
        ViewSystolicBloodPressure_jTextField3 = new javax.swing.JTextField();
        ViewWeight_jTextField4 = new javax.swing.JTextField();
        ViewPatientFirstName_jLabel1 = new javax.swing.JLabel();
        PatientId_jLabel2 = new javax.swing.JLabel();
        ViewPrimaryDoctorName_jLabel3 = new javax.swing.JLabel();
        ViewAge_jTextField5 = new javax.swing.JTextField();
        ViewPatientFirstName_jTextField1 = new javax.swing.JTextField();
        ViewPatientId_jTextField2 = new javax.swing.JTextField();
        ViewDoctorName_jTextField3 = new javax.swing.JTextField();
        ViewPatientLastName_jLabel4 = new javax.swing.JLabel();
        ViewAge_jLabel5 = new javax.swing.JLabel();
        ViewPreferredPharmacy_jLabel6 = new javax.swing.JLabel();
        View_PatientLastName_jTextField4 = new javax.swing.JTextField();
        ViewPreferredPharmacy_jTextField6 = new javax.swing.JTextField();
        timeStamp = new javax.swing.JLabel();
        dateStampText = new javax.swing.JTextField();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        vitalSignjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "DATE TIME", "HEALTH STATUS"
            }
        ));
        jScrollPane1.setViewportView(vitalSignjTable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 240, 100));

        Remove_jButton2.setText("Remove");
        Remove_jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Remove_jButton2ActionPerformed(evt);
            }
        });
        add(Remove_jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, 150, 50));

        View_jButton3.setText("View");
        View_jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                View_jButton3ActionPerformed(evt);
            }
        });
        add(View_jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 30, 170, 50));

        ViewRespiratoryRate_jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewRespiratoryRate_jLabel1.setText("Respiratory rate");
        add(ViewRespiratoryRate_jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 330, 123, 30));

        ViewHeartRate_jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewHeartRate_jLabel2.setText("Heart rate");
        add(ViewHeartRate_jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 390, 140, 30));
        add(ViewRespiratoryRate_jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 330, 190, 30));

        ViewHeartRate_jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewHeartRate_jTextField2ActionPerformed(evt);
            }
        });
        add(ViewHeartRate_jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, 190, 30));

        ViewSystolicBloodPressure_jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewSystolicBloodPressure_jLabel3.setText("Systolic blood pressure ");
        add(ViewSystolicBloodPressure_jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 150, 31));

        ViewWeight_jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewWeight_jLabel4.setText("Weight in pounds");
        add(ViewWeight_jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 140, 31));
        add(ViewSystolicBloodPressure_jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 160, 30));
        add(ViewWeight_jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 390, 160, 30));

        ViewPatientFirstName_jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewPatientFirstName_jLabel1.setText("Patient First Name");
        add(ViewPatientFirstName_jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 130, 30));

        PatientId_jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        PatientId_jLabel2.setText("Patient Id");
        add(PatientId_jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 112, 30));

        ViewPrimaryDoctorName_jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewPrimaryDoctorName_jLabel3.setText("Primary Doctor Name");
        add(ViewPrimaryDoctorName_jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 140, 160, 30));
        add(ViewAge_jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 160, 30));

        ViewPatientFirstName_jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ViewPatientFirstName_jTextField1ActionPerformed(evt);
            }
        });
        add(ViewPatientFirstName_jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, 160, 30));
        add(ViewPatientId_jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 160, 30));
        add(ViewDoctorName_jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 190, 30));

        ViewPatientLastName_jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewPatientLastName_jLabel4.setText("Patient Last Name");
        add(ViewPatientLastName_jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 160, 30));

        ViewAge_jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewAge_jLabel5.setText("Age");
        add(ViewAge_jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 110, 30));

        ViewPreferredPharmacy_jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ViewPreferredPharmacy_jLabel6.setText("Preferred Pharmacy");
        add(ViewPreferredPharmacy_jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, 170, 30));
        add(View_PatientLastName_jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 190, 190, 30));
        add(ViewPreferredPharmacy_jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 450, 160, 30));

        timeStamp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        timeStamp.setText("Date Timestamp");
        add(timeStamp, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 150, 32));

        dateStampText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateStampTextActionPerformed(evt);
            }
        });
        add(dateStampText, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 190, 30));
    }// </editor-fold>//GEN-END:initComponents
    private void ViewPatientFirstName_jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewPatientFirstName_jTextField1ActionPerformed
    }//GEN-LAST:event_ViewPatientFirstName_jTextField1ActionPerformed
    private void Remove_jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Remove_jButton2ActionPerformed
       int selectedrow = vitalSignjTable.getSelectedRow()  ;  
        if(selectedrow >= 0)
        {
        int option = JOptionPane.showConfirmDialog(null,"Are you sure to remove?","warning", JOptionPane.YES_NO_OPTION);
        if(option==JOptionPane.YES_OPTION)
            {
            VitalSign vs = (VitalSign)vitalSignjTable.getValueAt(selectedrow, 0);  
            vsh.removeVitalSign(vs);
            populate();
            }
        }
    }//GEN-LAST:event_Remove_jButton2ActionPerformed

    private void View_jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_View_jButton3ActionPerformed
      int selectedrow = vitalSignjTable.getSelectedRow();
      if(selectedrow  >= 0){

VitalSign vs = (VitalSign)vitalSignjTable.getValueAt(selectedrow,0);
 ViewPatientFirstName_jTextField1.setText(String.valueOf(p.getPatientFirstName()));
 View_PatientLastName_jTextField4.setText(String.valueOf(p.getPatientLastName()));
 ViewPatientId_jTextField2.setText(String.valueOf(p.getPatientId()));
 ViewAge_jTextField5.setText(String.valueOf(p.getAge()));
 ViewDoctorName_jTextField3.setText(String.valueOf(p.getDoctorName()));
 ViewPreferredPharmacy_jTextField6.setText(String.valueOf(p.getPreferredPharmacy()));
ViewHeartRate_jTextField2.setText(String.valueOf(vs.getHeartRate()));
ViewRespiratoryRate_jTextField1.setText(String.valueOf(vs.getRespiratoryRate()));
ViewSystolicBloodPressure_jTextField3.setText(String.valueOf(vs.getSystolicBloodPressure()));
dateStampText.setText(String.valueOf(vs.getDateTimeStamp()));
ViewWeight_jTextField4.setText(String.valueOf(vs.getWeightInPounds()));
   }                                           
else {
    JOptionPane.showMessageDialog(null, "no rows are selected");  
    }  
    }//GEN-LAST:event_View_jButton3ActionPerformed

    private void ViewHeartRate_jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ViewHeartRate_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ViewHeartRate_jTextField2ActionPerformed

    private void dateStampTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateStampTextActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dateStampTextActionPerformed
                                                                                                     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel PatientId_jLabel2;
    private javax.swing.JButton Remove_jButton2;
    private javax.swing.JLabel ViewAge_jLabel5;
    private javax.swing.JTextField ViewAge_jTextField5;
    private javax.swing.JTextField ViewDoctorName_jTextField3;
    private javax.swing.JLabel ViewHeartRate_jLabel2;
    private javax.swing.JTextField ViewHeartRate_jTextField2;
    private javax.swing.JLabel ViewPatientFirstName_jLabel1;
    private javax.swing.JTextField ViewPatientFirstName_jTextField1;
    private javax.swing.JTextField ViewPatientId_jTextField2;
    private javax.swing.JLabel ViewPatientLastName_jLabel4;
    private javax.swing.JLabel ViewPreferredPharmacy_jLabel6;
    private javax.swing.JTextField ViewPreferredPharmacy_jTextField6;
    private javax.swing.JLabel ViewPrimaryDoctorName_jLabel3;
    private javax.swing.JLabel ViewRespiratoryRate_jLabel1;
    private javax.swing.JTextField ViewRespiratoryRate_jTextField1;
    private javax.swing.JLabel ViewSystolicBloodPressure_jLabel3;
    private javax.swing.JTextField ViewSystolicBloodPressure_jTextField3;
    private javax.swing.JLabel ViewWeight_jLabel4;
    private javax.swing.JTextField ViewWeight_jTextField4;
    private javax.swing.JTextField View_PatientLastName_jTextField4;
    private javax.swing.JButton View_jButton3;
    private javax.swing.JTextField dateStampText;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel timeStamp;
    private javax.swing.JTable vitalSignjTable;
    // End of variables declaration//GEN-END:variables
}
