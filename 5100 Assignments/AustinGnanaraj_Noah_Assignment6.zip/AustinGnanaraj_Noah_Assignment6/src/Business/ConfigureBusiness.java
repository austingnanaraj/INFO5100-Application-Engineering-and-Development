/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class ConfigureBusiness {
    public static Business Initialize(){
        Business business=Business.getInstance();
        UserAccount u=business.getUserAccountDirectory().addUserAccount();
        u.setRole(UserAccount.admin);
        u.setPassword("admin");
        u.setUserName("admin");
        u.setStatus("Active");
        return business;
    }
}
