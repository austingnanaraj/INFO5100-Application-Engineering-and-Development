/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class SupplierDirectory {

    private ArrayList<Supplier> supplierDirectory;

    public SupplierDirectory() {
        supplierDirectory = new ArrayList<Supplier>();
    }

    public ArrayList<Supplier> getSupplierDirectory() {
        return supplierDirectory;
    }

    public void setSupplierDirectory(ArrayList<Supplier> supplierDirectory) {
        this.supplierDirectory = supplierDirectory;
    }

    public Supplier addSupplier() {
        Supplier p = new Supplier();
        supplierDirectory.add(p);
        return p;
    }

    public void removeSupplier(Supplier p) {
        supplierDirectory.remove(p);
    }

    public boolean duplicateSupplierName(String name) {
        for (Supplier sup : supplierDirectory) {
            if(sup.getName().equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }
    public boolean duplicateSupplierEMail(String eMail) {
        for (Supplier sup : supplierDirectory) {
            if(sup.geteMail().equalsIgnoreCase(eMail)) {
                return true;
            }
        }
        return false;
    }
}
