/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class Supplier extends Person {
    
    private String eMail,address,state;
    private int zipcode;
    private ProductDirectory pD;
    public Supplier(){
        pD= new ProductDirectory();
    }

//    public String getSupplier() {
//        return name;
//    }
//
//    public void setSupplier(String supplier) {
//        this.name = supplier;
//    }

    public ProductDirectory getpD() {
        return pD;
    }

    public void setpD(ProductDirectory pD) {
        this.pD = pD;
        
    }


    @Override
    public String toString() {
        return super.getName();
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getZipcode() {
        return zipcode;
    }

    public void setZipcode(int zipcode) {
        this.zipcode = zipcode;
    }
    
   
}
