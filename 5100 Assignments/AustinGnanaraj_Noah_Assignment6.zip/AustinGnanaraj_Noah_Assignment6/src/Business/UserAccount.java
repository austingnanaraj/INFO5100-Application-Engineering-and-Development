/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class UserAccount {
    private String userName,password,status,role;
    public static final String admin="admin";
    //public static final String employee="Employee";
    public static final String customer="customer";
    public static final String supplier="supplier";
    private Person person;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
   

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return userName;
    }
    
}
