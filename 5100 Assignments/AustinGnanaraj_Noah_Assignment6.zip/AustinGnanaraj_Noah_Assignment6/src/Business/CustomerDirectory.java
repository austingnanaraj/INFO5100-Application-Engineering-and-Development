/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class CustomerDirectory {

    private ArrayList<Customer> customerDirectory;

    public CustomerDirectory() {
        customerDirectory = new ArrayList<Customer>();
    }

    public ArrayList<Customer> getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(ArrayList<Customer> customerDirectory) {
        this.customerDirectory = customerDirectory;
    }

    public Customer addCustomer() {
        Customer p = new Customer();
        customerDirectory.add(p);
        return p;
    }

    public void removeCustomer(Customer p) {
        customerDirectory.remove(p);
    }

    public boolean duplicateCustomer(String name) {
        for (Customer customer : customerDirectory) {
            if (customer.getName().equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }
    public boolean duplicateEMail(String eMail){
        for (Customer customer : customerDirectory) {
            if (customer.geteMail().equalsIgnoreCase(eMail)) {
                return true;
            }
        }
        return false;
    }
}
