/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class Patient {
    private String patientName,patientId,doctorName,preferredPharmacy; // declarations
    private int age;
    public Patient(){
        vsh= new VitalSignHistory(); 
    }
    
    @Override
    public String toString() {
        return  patientName ;
    }

    public String getPatientName() {
        return patientName;
    }


    public String patientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getPreferredPharmacy() {
        return preferredPharmacy;
    }

    public void setPreferredPharmacy(String preferredPharmacy) {
        this.preferredPharmacy = preferredPharmacy;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
        private VitalSignHistory vsh;

    public VitalSignHistory getVsh() { // Getter and setter for VitalSignHistory
        return vsh;
    }

    public void setVsh(VitalSignHistory vsh) {
        this.vsh = vsh;
    }
//    public String getVitalSign(VitalSign vs){
//        String a;
//        a= "No Status";
//         if (this.age >= 1 && this.age <= 3) {
//             
//            if (vs.getRespiratoryRate()>= 20 && vs.getRespiratoryRate() <= 30
//                    && vs.getHeartRate() >= 80 && vs.getHeartRate() <= 130
//                    && vs.getSystolicBloodPressure() >= 80
//                    && vs.getSystolicBloodPressure() <= 110
//                    && vs.getWeightInPounds() >= 22
//                    && vs.getWeightInPounds() <= 31) {
//                a="Normal";
//                return a;
//            } else {
//                a="Abnormal";
//                return a;
//            }
//        
//        }
//       if (this.age >= 4 && this.age <= 5) {
//            if (vs.getRespiratoryRate() >= 20 && vs.getRespiratoryRate() <= 30
//                    && vs.getHeartRate() >= 80 && vs.getHeartRate() <= 120
//                    && vs.getSystolicBloodPressure() >= 80
//                    && vs.getSystolicBloodPressure() <= 110
//                    && vs.getWeightInPounds() >= 31
//                    && vs.getWeightInPounds() >= 40) {
//                a="Normal";
//                return a;
//            } else {
//                a="Abnormal";
//                return a;
//            }
//
//        }
//        if (this.age >= 6 && this.age <= 12) {
//            if (vs.getRespiratoryRate() >= 20 && vs.getRespiratoryRate() <= 30
//                    && vs.getHeartRate() >= 70 && vs.getHeartRate() <= 110
//                    && vs.getSystolicBloodPressure() >= 80
//                    && vs.getSystolicBloodPressure() <= 110
//                    && vs.getWeightInPounds() >= 41
//                    && vs.getWeightInPounds() >= 92) {
//                a="Normal";
//                return a;
//            } else {
//                a="Abnormal";
//                return a;
//            }
//
//        }
//        if (this.age >= 13) {
//            if (vs.getRespiratoryRate() >= 12 && vs.getRespiratoryRate() <= 20
//                    && vs.getHeartRate() >= 55 && vs.getHeartRate() <= 105
//                    && vs.getSystolicBloodPressure() >= 110
//                    && vs.getSystolicBloodPressure() <= 120
//                    && vs.getWeightInPounds() > 110) {
//                a="Normal";
//                return a;
//            } else {
//                a="Abnormal";
//                return a;
//
//            }
//
//        }return a ;
//} 
}
    

