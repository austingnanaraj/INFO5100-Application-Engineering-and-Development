/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class VitalSignHistory {
     private ArrayList<VitalSign> vitalSignHistory;

 public VitalSignHistory(){ //Constructor to create a new ArrayList
       vitalSignHistory=new ArrayList<>();
   }

    public ArrayList<VitalSign> getVsd() {
        return vitalSignHistory;
    }

    public void setVsd(ArrayList<VitalSign> vsd) {
        this.vitalSignHistory = vsd;
    }
 
 public VitalSign addVitalSign(){
     VitalSign vs= new VitalSign();
       vitalSignHistory.add(vs);
       return vs;
 }
 public void removeVitalSign(VitalSign vs){
       vitalSignHistory.remove(vs);    
   }
 }
