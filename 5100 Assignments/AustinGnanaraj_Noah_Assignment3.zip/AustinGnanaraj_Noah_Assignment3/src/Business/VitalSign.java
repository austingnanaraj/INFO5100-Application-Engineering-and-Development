/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class VitalSign {
    public VitalSign(){
       vsh= new VitalSignHistory();
    }
    private float heartRate,respiratoryRate;
    private float systolicBloodPressure,weightInPounds;
    private String dateTimeStamp;
    VitalSignHistory vsh;

    public VitalSignHistory getVsh() {
        return vsh;
    }

    public void setVsh(VitalSignHistory vsh) {
        this.vsh = vsh;
    }


    public float getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(float heartRate) {
        this.heartRate = heartRate;
    }

    public float getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(float respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public float getSystolicBloodPressure() {
        return systolicBloodPressure;
    }

    public void setSystolicBloodPressure(float systolicBloodPressure) {
        this.systolicBloodPressure = systolicBloodPressure;
    }

    public float getWeightInPounds() {
        return weightInPounds;
    }

    public void setWeightInPounds(float weightInPounds) {
        this.weightInPounds = weightInPounds;
    }

    public String getDateTimeStamp() {
        return dateTimeStamp;
    }

    public void setDateTimeStamp(String dateTimeStamp) {
        this.dateTimeStamp = dateTimeStamp;
    }

    @Override
    public String toString() {
        return dateTimeStamp;
    }
    

    public String getVitalSign(int age){
        String a;
        a= "No Status";
         if (age >= 1 && age <= 3) {
             
            if (this.getRespiratoryRate()>= 20 && this.getRespiratoryRate() <= 30
                    && this.getHeartRate() >= 80 && this.getHeartRate() <= 130
                    && this.getSystolicBloodPressure() >= 80
                    && this.getSystolicBloodPressure() <= 110
                    && this.getWeightInPounds() >= 22
                    && this.getWeightInPounds() <= 31) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }
        
        }
       if (age >= 4 && age <= 5) {
            if (this.getRespiratoryRate() >= 20 && this.getRespiratoryRate() <= 30
                    && this.getHeartRate() >= 80 && this.getHeartRate() <= 120
                    && this.getSystolicBloodPressure() >= 80
                    && this.getSystolicBloodPressure() <= 110
                    && this.getWeightInPounds() >= 31
                    && this.getWeightInPounds() >= 40) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }

        }
        if (age >= 6 && age <= 12) {
            if (this.getRespiratoryRate() >= 20 && this.getRespiratoryRate() <= 30
                    && this.getHeartRate() >= 70 && this.getHeartRate() <= 110
                    && this.getSystolicBloodPressure() >= 80
                    && this.getSystolicBloodPressure() <= 110
                    && this.getWeightInPounds() >= 41
                    && this.getWeightInPounds() >= 92) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;
            }

        }
        if (age >= 13) {
            if (this.getRespiratoryRate() >= 12 && this.getRespiratoryRate() <= 20
                    && this.getHeartRate() >= 55 && this.getHeartRate() <= 105
                    && this.getSystolicBloodPressure() >= 110
                    && this.getSystolicBloodPressure() <= 120
                    && this.getWeightInPounds() > 110) {
                a="Normal";
                return a;
            } else {
                a="Abnormal";
                return a;

            }

        }return a ;
} 

}
