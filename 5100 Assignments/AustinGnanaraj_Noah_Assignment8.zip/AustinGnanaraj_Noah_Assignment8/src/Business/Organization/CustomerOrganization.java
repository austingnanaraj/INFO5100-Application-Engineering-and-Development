/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Customer.Customer;
import Business.Roles.CustomerRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author Austin Gnanaraj
 */
public class CustomerOrganization extends Organization {



    public CustomerOrganization() {
        super(Organization.Type.CUSTOMER.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new CustomerRole());
        return role;
    }

    public Customer addCustomer() {
        Customer customer = new Customer();
        personList.add(customer);

        return customer;
    }

    public void removeCustomer(Customer s) {
        personList.remove(s);
    }



}
