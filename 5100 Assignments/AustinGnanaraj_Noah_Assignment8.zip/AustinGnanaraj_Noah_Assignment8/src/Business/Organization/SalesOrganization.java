/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import static Business.Organization.Organization.Type.SALES;
import Business.Roles.Roles;
import static Business.Roles.Roles.RoleType.SALESROLE;
import Business.Roles.SalesRole;
import Business.SalesRepresentative.Sales;
import java.util.ArrayList;

/**
 *
 * @author Austin Gnanaraj
 */
public class SalesOrganization extends Organization{
     public SalesOrganization() {
        super(Organization.Type.SALES.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new SalesRole());
        return role;
    }

   public Sales addSalesRepresentative() {
        Sales salesRep = new Sales();
        personList.add(salesRep);

        return salesRep;
    }

    public void removeSalesRepresentative(Sales salesRep) {
        personList.remove(salesRep);
    }



    
}
