/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Roles.Roles;
import Business.Roles.ShippingRole;
import Business.Shipment.Shipping;
import java.util.ArrayList;

/**
 *
 * @author Austin Gnanaraj
 */
public class ShippingOrganization extends Organization{
    public ShippingOrganization() {
        super(Organization.Type.SHIPPING.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new ShippingRole());
        return role;
    }

    public Shipping addShipmentRep() {
        Shipping shipmentRepresentative = new Shipping();
        personList.add(shipmentRepresentative);

        return shipmentRepresentative;
    }

    public void removeShipmentRepresentative(Shipping shipmentRepresentative) {
        personList.remove(shipmentRepresentative);
    }



    
    
}
