/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Roles.SupplierRole;
import Business.Roles.Roles;
import Business.Supplier.Supplier;
import java.util.ArrayList;

/**
 *
 * @author Austin Gnanaraj
 */
public class SupplierOrganization extends Organization {

    public SupplierOrganization() {
        super(Organization.Type.SUPPLIER.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new SupplierRole());
        return role;
    }

    public Supplier addSupplier() {
        Supplier s = new Supplier();
        personList.add(s);

        return s;
    }

    public void removeSupplier(Supplier s) {
        personList.remove(s);
    }

}
