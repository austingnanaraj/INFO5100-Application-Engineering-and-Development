/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

import java.util.ArrayList;

/**
 *
 * @author Austin Gnanaraj
 */
public class ProductCatalog {

    private ArrayList<Product> productCatalogList;

    public ProductCatalog() {
        productCatalogList = new ArrayList<Product>();
    }

    public Product addProduct() {
        Product p = new Product();
        productCatalogList.add(p);
        return p;
    }

    public void removeProduct(Product p) {
        productCatalogList.remove(p);
    }

    public ArrayList<Product> getProductDirectory() {
        return productCatalogList;
    }

    public void setProductDirectory(ArrayList<Product> productDirectory) {
        this.productCatalogList = productDirectory;
    }

    public Product SearchResult(int productID) {

        for (Product product : productCatalogList) {
            if (product.getModelNo() == (productID)) {

                return product;
            }
        }
        return null;
    }

    public boolean duplicateProduct(String item) {
        for (Product product : productCatalogList) {
            if (product.getName().equals(item)) {
                return true;
            }
        }
        return false;
    }
}
