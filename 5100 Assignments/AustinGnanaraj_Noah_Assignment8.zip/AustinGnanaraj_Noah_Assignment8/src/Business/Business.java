/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Order.MasterOrderCatalog;
import Business.Organization.CustomerOrganization;
import Business.Organization.OrganizationDirectory;
import Business.Organization.SalesOrganization;
import Business.Organization.ShippingOrganization;
import Business.Organization.SupplierOrganization;

/**
 *
 * @author Austin Gnanaraj
 */
public class Business {

    public static Business business;
    public static SupplierOrganization supplierOrganization;
    public static CustomerOrganization customerOrganization;
    public static SalesOrganization salesSpecialistOrganization;
    public static ShippingOrganization shipmentOrganization;
    private MasterOrderCatalog masterOrderCatalog;

    private OrganizationDirectory organizationDirectory;

    private Business() {

        masterOrderCatalog = new MasterOrderCatalog();
        organizationDirectory = new OrganizationDirectory();
    }

    public static Business getInstance() {
        if (business == null) {
            business = new Business();
        }
        if (supplierOrganization == null) {
            supplierOrganization = new SupplierOrganization();
            business.getOrganizationDirectory().getOrganizationList().add(supplierOrganization);
        }
        if (customerOrganization == null) {
            customerOrganization = new CustomerOrganization();
            business.getOrganizationDirectory().getOrganizationList().add(customerOrganization);
        }
        if(salesSpecialistOrganization==null)
        {
           salesSpecialistOrganization=new  SalesOrganization();
           business.getOrganizationDirectory().getOrganizationList().add(salesSpecialistOrganization);
        }
        if(shipmentOrganization==null)
        {
            shipmentOrganization= new ShippingOrganization();
            business.getOrganizationDirectory().getOrganizationList().add(shipmentOrganization);
            
        }
        return business;

    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    public MasterOrderCatalog getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public void setMasterOrderCatalog(MasterOrderCatalog masterOrderCatalog) {
        this.masterOrderCatalog = masterOrderCatalog;
    }

}
