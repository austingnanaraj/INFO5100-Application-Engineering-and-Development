/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Customer.Customer;
import Business.Product.ProductCatalog;
import Business.SalesRepresentative.Sales;
import Business.Shipment.Shipping;
import Business.Supplier.Supplier;

public class Person {

    private String name;
    private int id;
    private static int counter;
    private Supplier supplier;
    private Customer customer;
    private Sales salesRep;
    private Shipping shipmentRep;

    public Person() {
        id = counter;
        counter++;
    }

    public String getName() {
        return name;
    }

    public Shipping getNewShipment() {
        shipmentRep = new Shipping();

        return shipmentRep;
    }

    public Sales getNewSalesRep() {
        salesRep = new Sales();

        return salesRep;
    }

    public Supplier getNewSupplier() {
        supplier = new Supplier();
        return supplier;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Customer getNewCustomer() {
        customer = new Customer();
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Sales getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(Sales salesRep) {
        this.salesRep = salesRep;
    }

    public Shipping getShipmentRep() {
        return shipmentRep;
    }

    public void setShipmentRep(Shipping shipmentRep) {
        this.shipmentRep = shipmentRep;
    }

    @Override
    public String toString() {
        return name;
    }

}
