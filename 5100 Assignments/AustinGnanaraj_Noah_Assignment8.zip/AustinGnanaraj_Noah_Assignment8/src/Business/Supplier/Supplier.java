/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Supplier;

import Business.Person.Person;
import Business.Product.ProductCatalog;

/**
 *
 * @author Austin Gnanaraj
 */
public class Supplier extends Person {

    private ProductCatalog productCatalog;
    private String address, state, eMailId;
    private int zipCode;
    private String statusSupplier;

    public Supplier() {
        productCatalog = new ProductCatalog();
    }

    public ProductCatalog getProductDirectory() {

        return productCatalog;
    }

    public void setProductDirectory(ProductCatalog pD) {
        this.productCatalog = pD;

    }

    public String getAddress() {
        return address;
    }

    public String getStatusSupplier() {
        return statusSupplier;
    }

    public void setStatusSupplier(String statusSupplier) {
        this.statusSupplier = statusSupplier;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String geteMail() {
        return eMailId;
    }

    public void seteMail(String eMailId) {
        this.eMailId = eMailId;
    }

    public int getZipcode() {
        return zipCode;
    }

    public void setZipcode(int zipCode) {
        this.zipCode = zipCode;
    }

    @Override
    public String toString() {
        return super.getName();
    }

}
