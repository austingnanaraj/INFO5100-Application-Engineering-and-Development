/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Roles;

import Business.Business;
import Business.Supplier.Supplier;
import Business.User.UserAccount;
import UserInterface.SupplierRole.SupplierWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author Austin Gnanaraj
 */
public class SupplierRole extends Roles {
 Supplier s;
    @Override

    public JPanel createWorkArea(JPanel userProcessContainer, Business business,String a,UserAccount ua) {
        return new SupplierWorkAreaJPanel(userProcessContainer, business,a,ua,s);
    }



}
