/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Roles;

import Business.Business;
import Business.User.UserAccount;
import UserInterface.ShippingRole.ShippingWorkAreaJPanel;
import javax.management.relation.Role;
import javax.swing.JPanel;

/**
 *
 * @author Austin Gnanaraj
 */
public class ShippingRole extends Roles {
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, Business business,String a,UserAccount ua) {
        return new ShippingWorkAreaJPanel(userProcessContainer, business,a,ua);
    }
    
}
