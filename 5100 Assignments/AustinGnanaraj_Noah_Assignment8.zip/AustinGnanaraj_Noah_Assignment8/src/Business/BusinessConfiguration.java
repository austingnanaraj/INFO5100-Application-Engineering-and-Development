/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Person.Person;
import Business.Organization.AdminOrganization;
import Business.Roles.AdminRole;
import Business.User.UserAccount;

/**
 *
 * @author Austin Gnanaraj
 */
public class BusinessConfiguration {

    public static Business configureBusiness() {
        Business business = Business.getInstance();
        AdminOrganization admin = new AdminOrganization();
        business.getOrganizationDirectory().getOrganizationList().add(admin);
        Person e = new Person();
        e.setName("AustinGnanaraj");
        admin.personList.add(e);
        UserAccount u = new UserAccount();
        u.setRole(new AdminRole());
        u.setUserName("admin");
        u.setPassword("admin");
        u.setStatus("active");
        admin.userAccountArrayList.add(u);
        return business;
    }
}
