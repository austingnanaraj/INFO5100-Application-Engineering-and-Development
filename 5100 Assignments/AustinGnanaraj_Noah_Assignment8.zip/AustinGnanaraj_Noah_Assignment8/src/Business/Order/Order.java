/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author Austin Gnanaraj
 */
public class Order {

    private ArrayList<OrderItem> order;
    private static int count;
    private int orderId;
    private String orderFor;
    private String deliveryStatus;

    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setDeliveryStatus(String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public String getDate() {
        String timeStamp = new SimpleDateFormat("dd/mm/yyyy").format(Calendar.getInstance().getTime());
        return timeStamp;
    }

    public Order() {
        order = new ArrayList<OrderItem>();
        count++;
        orderId = count;
    }

    public ArrayList<OrderItem> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<OrderItem> order) {
        this.order = order;
    }

    public String getOrderFor() {
        return orderFor;
    }

    public void setOrderFor(String orderFor) {
        this.orderFor = orderFor;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public ArrayList<OrderItem> getOrders() {
        return order;
    }

    public void setOrders(ArrayList<OrderItem> orders) {
        this.order = orders;
    }

    public OrderItem addOrderItem() {
        OrderItem oi = new OrderItem();
        order.add(oi);
        return oi;
    }

    public void removeOrderItem(OrderItem oi) {
        order.remove(oi);
    }
}
