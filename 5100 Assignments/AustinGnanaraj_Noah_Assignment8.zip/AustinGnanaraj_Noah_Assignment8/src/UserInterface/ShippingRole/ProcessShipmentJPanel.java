package UserInterface.ShippingRole;

import Business.Business;
import Business.Customer.Customer;
import Business.Order.Order;
import Business.Organization.CustomerOrganization;
import Business.Organization.Organization;
import Business.Person.Person;
import Business.User.UserAccount;
import Business.WorkQueue.WorkRequest;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ProcessShipmentJPanel extends javax.swing.JPanel {

    JPanel userProcessContainer;
    WorkRequest request;
    UserAccount ua;
    Business business;
    Customer cus;

    //Organization cusorg;
    public ProcessShipmentJPanel(JPanel userProcessContainer, WorkRequest request, UserAccount ua, Business business) {
        initComponents();
        this.request = request;
        this.business=business;
        this.userProcessContainer = userProcessContainer;
        for (Order o : business.getMasterOrderCatalog().getMasterOrderCatalog()) {
            int c = Integer.parseInt(request.getMessage()) - 1;
            if (c == o.getOrderId()) {
                Organization org = null;
                for (Organization organization : business.getOrganizationDirectory().getOrganizationList()) {
                    if (organization instanceof CustomerOrganization) {
                        org = organization;
                        break;
                    }
                }
                if (org != null) {
                    for (Person per : org.getPersonArrayList()) {
                        if (per.getName() == o.getOrderFor()) {
                            Customer cus = per.getCustomer();
                            this.cus = cus;
                        }
                    }
                }
                o.getOrderFor();
            }
        }

        supplierName.setText(cus.getName());
        txtAddress.setText(cus.getAddress());
        txtEMail.setText(cus.geteMail());
        txtState.setText(cus.getState());
        txtSupplierName.setText(cus.getName());
        txtZipCode.setText(String.valueOf(cus.getZipCode()));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        supplierName = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        txtSupplierName = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtState = new javax.swing.JTextField();
        txtZipCode = new javax.swing.JTextField();
        txtEMail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnProcess = new javax.swing.JButton();
        txtName = new javax.swing.JTextField();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        supplierName.setText("jLabel1");
        add(supplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 32, -1, -1));

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 130, 40));

        txtSupplierName.setEditable(false);
        add(txtSupplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 91, 130, 33));

        txtAddress.setEditable(false);
        add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 136, 130, 36));

        txtState.setEditable(false);
        add(txtState, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 190, 130, 33));

        txtZipCode.setEditable(false);
        add(txtZipCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 241, 130, 36));

        txtEMail.setEditable(false);
        add(txtEMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 295, 130, -1));

        jLabel1.setText("Customer Name");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 91, 106, 33));

        jLabel2.setText("Address");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 136, 106, 36));

        jLabel3.setText("State");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 190, 106, 33));

        jLabel4.setText("ZipCode");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 241, 106, 36));

        jLabel5.setText("E-Mail");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 295, 114, 28));

        jLabel6.setText("VIEW CUSTOMER");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, -1, -1));

        btnProcess.setText("Process");
        btnProcess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProcessActionPerformed(evt);
            }
        });
        add(btnProcess, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 390, 120, 40));
        add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 290, 200, 40));
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
        JOptionPane.showMessageDialog(null, "Please press the refresh button");
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnProcessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProcessActionPerformed
        //request.setTestResult(txtName.getText());
        request.setStatus("Completed");
//        int e = Integer.parseInt(request.getMessage());
//        for (Order o : business.getMasterOrderCatalog().getMasterOrderCatalog()) {
//            if (o.getOrderId() == e - 1) {
//                o.setDeliveryStatus("Shipped");
//
//            }
//        }
        int m = Integer.parseInt(request.getMessage());
        for (Order o : business.getMasterOrderCatalog().getMasterOrderCatalog()) {
            if (m - 1 == o.getOrderId()) {
                o.setDeliveryStatus("Shipped");
            }
        }
    }//GEN-LAST:event_btnProcessActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnProcess;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel supplierName;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtEMail;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtState;
    private javax.swing.JTextField txtSupplierName;
    private javax.swing.JTextField txtZipCode;
    // End of variables declaration//GEN-END:variables
}
