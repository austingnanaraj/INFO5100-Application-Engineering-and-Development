package UserInterface.AdminRole;

import Business.Product.Product;
import Business.Supplier.Supplier;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ViewSupplier extends javax.swing.JPanel {

    JPanel userProcessContainer;
    Supplier s;

    public ViewSupplier(JPanel userProcessContainer, Supplier s) {
        initComponents();
        this.s = s;
        this.userProcessContainer = userProcessContainer;
        supplierName.setText(s.getName());
        txtAddress.setText(s.getAddress());
        txtEMail.setText(s.geteMail());
        txtState.setText(s.getState());
        txtSupplierName.setText(s.getName());
        txtZipCode.setText(String.valueOf(s.getZipcode()));
        populateTable();
        if (s.getProductDirectory().getProductDirectory().size() < 1) {
            JOptionPane.showMessageDialog(null, "Supplier has not add products yet");
        }
    }

    public void populateTable() {
        DefaultTableModel dtm = (DefaultTableModel) productCatalogJTable.getModel();
        dtm.setRowCount(0);
        for (Product p : s.getProductDirectory().getProductDirectory()) {
            Object row[] = new Object[3];
            row[0] = p;
            row[1] = p.getModelNo();
            row[2] = p.getPrice();
            dtm.addRow(row);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        supplierName = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        productCatalogJTable = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        txtSupplierName = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtState = new javax.swing.JTextField();
        txtZipCode = new javax.swing.JTextField();
        txtEMail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        supplierName.setText("jLabel1");
        add(supplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 32, -1, -1));

        productCatalogJTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Product Name", "Product ID", "Product Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(productCatalogJTable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 60, 330, 104));

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 380, 130, 40));

        txtSupplierName.setEditable(false);
        add(txtSupplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 91, 130, 33));

        txtAddress.setEditable(false);
        add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 136, 130, 36));

        txtState.setEditable(false);
        add(txtState, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 190, 130, 33));

        txtZipCode.setEditable(false);
        add(txtZipCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 241, 130, 36));

        txtEMail.setEditable(false);
        add(txtEMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 295, 130, -1));

        jLabel1.setText("Supplier Name");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 91, 106, 33));

        jLabel2.setText("Address");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 136, 106, 36));

        jLabel3.setText("State");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 190, 106, 33));

        jLabel4.setText("ZipCode");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 241, 106, 36));

        jLabel5.setText("E-Mail");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 295, 114, 28));

        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 262, 39));

        btnSave.setText("SAVE");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 350, 262, 40));

        jLabel6.setText("VIEW SUPPLIER");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
        JOptionPane.showMessageDialog(null, "Please press the refresh button");
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        txtAddress.setEditable(true);
        txtEMail.setEditable(true);
        txtState.setEditable(true);
        txtSupplierName.setEditable(true);
        txtZipCode.setEditable(true);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        s.setAddress(txtAddress.getText());
        s.setName(txtSupplierName.getText());
        s.setState(txtState.getText());
        s.setZipcode(Integer.parseInt(txtZipCode.getText()));
        s.seteMail(txtEMail.getText());
        JOptionPane.showMessageDialog(null, "Supplier Details Saved");
        txtAddress.setEditable(false);
        txtEMail.setEditable(false);
        txtState.setEditable(false);
        txtSupplierName.setEditable(false);
        txtZipCode.setEditable(false);
    }//GEN-LAST:event_btnSaveActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable productCatalogJTable;
    private javax.swing.JLabel supplierName;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtEMail;
    private javax.swing.JTextField txtState;
    private javax.swing.JTextField txtSupplierName;
    private javax.swing.JTextField txtZipCode;
    // End of variables declaration//GEN-END:variables
}
