package UserInterface.SupplierRole;

import Business.Business;
import Business.Person.Person;
import Business.Order.MasterOrderCatalog;
import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Supplier.Supplier;
import Business.User.UserAccount;
import java.awt.CardLayout;
import java.util.ArrayList;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.swing.JPanel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class SupplierWorkAreaJPanel extends javax.swing.JPanel {

    JPanel userProcessContainer;
    Person person;
    MasterOrderCatalog masterOrderCatalog;
    Business business;
    String userName, password;
    UserAccount userAccount;
    Supplier supplier;
    OrganizationDirectory od;
    ArrayList<UserAccount> userAccountDirectory;

    public SupplierWorkAreaJPanel(JPanel userProcessContainer, Business business, String a,UserAccount userAccount,Supplier s) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.business=business;
        this.userAccount=userAccount;
        this.supplier=s;
        this.od=business.getOrganizationDirectory();
        for (Organization org : business.getOrganizationDirectory().getOrganizationList()) {
             if(org.getName()=="Admin Organization"){
                userAccountDirectory= org.getUserAccountArrayList();
             }
         }
        for (Organization organization : business.getOrganizationDirectory().getOrganizationList()) {
            String organizationName = organization.getName();
            boolean value = true;
            if (organizationName == "Supplier Organization") {
                for (Person per : organization.getPersonArrayList()) {
                  
                    if (value == true) {
                        for (UserAccount ua : userAccountDirectory) {
                        if (a.equals(ua.getUserName())) {
                                
                                if (per.getName().equals(ua.getPerson().getName())) {
                                   
                                    supplier = per.getSupplier();
                                    value = false;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        managePButton = new javax.swing.JButton();
        reportButton4 = new javax.swing.JButton();
        btnSupplierRequest = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("My Work Area (Product Manager Role)");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 30, -1, -1));

        managePButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        managePButton.setText("Manage Product Catalog >>");
        managePButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                managePButtonActionPerformed(evt);
            }
        });
        add(managePButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, -1, -1));

        reportButton4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        reportButton4.setText("Review Product Performance >>");
        reportButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportButton4ActionPerformed(evt);
            }
        });
        add(reportButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, -1, -1));

        btnSupplierRequest.setText("SUPPLIER WORK REQUEST >>");
        btnSupplierRequest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupplierRequestActionPerformed(evt);
            }
        });
        add(btnSupplierRequest, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, -1, -1));
    }// </editor-fold>//GEN-END:initComponents
    private void managePButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_managePButtonActionPerformed
        ManageProductCatalogJPanel panel = new ManageProductCatalogJPanel(userProcessContainer, supplier);
        userProcessContainer.add("ManageProductCataglog", panel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_managePButtonActionPerformed

    private void reportButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportButton4ActionPerformed
        ProductReportJPanel panel = new ProductReportJPanel(userProcessContainer, supplier);
        userProcessContainer.add("ReportJPanel", panel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_reportButton4ActionPerformed

    private void btnSupplierRequestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupplierRequestActionPerformed
        // TODO add your handling code here:
          RequestEnrollSupplierJPanel requestToAddSupplierJPanel = new RequestEnrollSupplierJPanel(userProcessContainer,od,userAccount,supplier);
        userProcessContainer.add("ManageShipping", requestToAddSupplierJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }                                                      
    public static boolean validEmail(String email) {
        boolean flag = true;
        try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
        } catch (AddressException ex) {
            flag = false;
        }
        return flag;
    }//GEN-LAST:event_btnSupplierRequestActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSupplierRequest;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton managePButton;
    private javax.swing.JButton reportButton4;
    // End of variables declaration//GEN-END:variables
}
