/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class Order {
    private ArrayList<OrderItem> order;
      private static int count;
      private int orderId;
    public Order(){
        order=new ArrayList<OrderItem>();
        count++;
        orderId = count;
        
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public ArrayList<OrderItem> getOrders() {
        return order;
    }

    public void setOrders(ArrayList<OrderItem> orders) {
        this.order = orders;
    }
    public OrderItem addOrderItem(){
        OrderItem oi= new OrderItem();
        order.add(oi);
        return oi;
    }
    public void removeOrderItem(OrderItem oi){
        order.remove(oi);
    }
    
    public OrderItem modifyOrderItem(OrderItem oi,int a){
        int c=a;
        oi.setQuantity(c);
        return oi;
    }
}
