/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author AustinGnanaraj
 */
public class Supplier {
    
    private String name;
    private ProductDirectory pD;
    public Supplier(){
        pD= new ProductDirectory();
    }

    public String getSupplier() {
        return name;
    }

    public void setSupplier(String supplier) {
        this.name = supplier;
    }

    public ProductDirectory getpD() {
        return pD;
    }

    public void setpD(ProductDirectory pD) {
        this.pD = pD;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
    
   
}
