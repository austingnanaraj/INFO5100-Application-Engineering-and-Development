/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class ProductDirectory {

    private ArrayList<Product> productDirectory;

    public ProductDirectory() {
        productDirectory = new ArrayList<Product>();
    }

    public Product addProduct() {
        Product p = new Product();
        productDirectory.add(p);
        return p;
    }

    public void removeProduct(Product p) {
        productDirectory.remove(p);
    }

    public ArrayList<Product> getProductDirectory() {
        return productDirectory;
    }

    public void setProductDirectory(ArrayList<Product> productDirectory) {
        this.productDirectory = productDirectory;
    }

    public Product SearchResult(int productID) {

        for (Product product : productDirectory) {
            if (product.getModelNo() == (productID)) {

                return product;
            }
        }
        return null;
    }

    public boolean duplicateProduct(String pro) {
        for (Product product : productDirectory) {
            if (product.getName().equals(pro)) {
                return true;
            }
        }
        return false;
    }
}
