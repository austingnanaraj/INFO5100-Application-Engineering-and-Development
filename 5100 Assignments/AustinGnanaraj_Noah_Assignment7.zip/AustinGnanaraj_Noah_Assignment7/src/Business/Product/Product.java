/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

/**
 *
 * @author AustinGnanaraj
 */
public class Product {

    private static int count = 0;
    private String name;
    private int modelNo;
    private float price;
    private int availability;
    private int oldAvailability;
    private int quantitySold = 0;
    private int totalAmountSold = 0;

    public int getOldAvailability() {
        return oldAvailability;
    }

    public void setOldAvailability(int oldAvailability) {
        this.oldAvailability = oldAvailability;
    }

    public int getQuantitySold() {
        return quantitySold;
    }

    public void setQuantitySold(int quantitySold) {
        this.quantitySold = quantitySold;
    }

    public int getTotalAmountSold() {
        return totalAmountSold;
    }

    public void setTotalAmountSold(int totalAmountSold) {
        this.totalAmountSold = totalAmountSold;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    @Override
    public String toString() {
        return name;
    }

    public Product() {
        count++;
        modelNo = count;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Product.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getModelNo() {
        return modelNo;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

}
