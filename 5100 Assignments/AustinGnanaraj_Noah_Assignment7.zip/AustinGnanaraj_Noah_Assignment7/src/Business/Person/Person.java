/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Customer.Customer;
import Business.Supplier.Supplier;

public class Person {

    private String name;
    private int id;
    private static int counter;
    private Supplier supplier;
    private Customer customer;

    public Person() {
        id = counter;
        counter++;
    }

    public String getName() {
        return name;
    }

    public Supplier getNewSupplier() {
        supplier = new Supplier();
        return supplier;
    }

//    public void removeSupplier(Supplier sup) {
//        supplier.removeSupplier(sup);
//    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Customer getNewCustomer() {
        customer = new Customer();
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return name;
    }

}
