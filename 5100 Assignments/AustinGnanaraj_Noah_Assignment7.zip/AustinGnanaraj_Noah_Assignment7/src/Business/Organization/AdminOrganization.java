/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Roles.AdminRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author AustinGnanaraj
 */
public class AdminOrganization extends Organization {

    public AdminOrganization() {
        super(Organization.Type.ADMIN.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {

        ArrayList<Roles> role = new ArrayList<>();
        role.add(new AdminRole());
        return role;

    }

}
