/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Person.Person;
import Business.Roles.Roles;
import Business.User.UserAccount;
import java.util.ArrayList;

//cannot be instantiated --> abstract class
public abstract class Organization {

    private String name;
    private int id;
    private static int counter = 1;
    public ArrayList<Person> personArrayList;
    public ArrayList<UserAccount> userAccountArrayList;

    public enum Type {
//three constants (green) ; orange - parameters of constant
// Organization is restricted(allowed to be) only to be these 3 using enum

        ADMIN("Admin Organization"),
        SUPPLIER("Supplier Organization"),
        CUSTOMER("Customer Organization");

        private String value;

//private constructor
        private Type(String name) {
            this.value = name;
        }

//get value gets parameters of constant
        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

    }

    //abstract method
    public abstract ArrayList<Roles> getSupportedRole();

    public Organization(String name) {
        this.name = name;
        personArrayList = new ArrayList<>();
        userAccountArrayList = new ArrayList<>();
        id = counter;
        counter++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Person> getPersonArrayList() {
        return personArrayList;
    }

    public void setPerson(ArrayList<Person> person) {
        this.personArrayList = person;
    }
    
    public ArrayList<UserAccount> getUserAccountArrayList() {
        return userAccountArrayList;
    }

    public void setUserAccount(ArrayList<UserAccount> userAccount) {
        this.userAccountArrayList = userAccount;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return name;
    }

    public UserAccount CreateUserAccount(String userName, String password, Person e, Roles role) {
        UserAccount ua = new UserAccount();
        ua.setUserName(userName);
        ua.setPassword(password);
        ua.setRole(role);
        userAccountArrayList.add(ua);
        return ua;
    }

    public UserAccount addUserAccount() {
        UserAccount u = new UserAccount();
        userAccountArrayList.add(u);
        return u;
    }

    public UserAccount authenticateUser(String userName, String password) {
        for (UserAccount ua : userAccountArrayList) {
            if (ua.getUserName().equals(userName) && ua.getPassword().equals(password)) {
                return ua;
            }
        }
        return null;
    }

    public Person createPerson() {
        Person p = new Person();
        personArrayList.add(p);
        return p;
    }

    public void removePerson(Person name) {
        personArrayList.remove(name);
    }
}
