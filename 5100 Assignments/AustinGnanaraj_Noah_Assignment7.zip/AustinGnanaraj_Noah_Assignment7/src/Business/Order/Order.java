/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author AustinGnanaraj
 */
public class Order {

    private ArrayList<OrderItem> order;
    private static int count;
    private int orderId;
    private String orderFor;

    public String getDate() {
        String timeStamp = new SimpleDateFormat("MM/dd/yyyy_HH:mm:ss").format(Calendar.getInstance().getTime());
        return timeStamp;
    }

    public Order() {
        order = new ArrayList<>();
        count++;
        orderId = count;
    }

    public ArrayList<OrderItem> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<OrderItem> order) {
        this.order = order;
    }

    public String getOrderFor() {
        return orderFor;
    }

    public void setOrderFor(String orderFor) {
        this.orderFor = orderFor;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public ArrayList<OrderItem> getOrders() {
        return order;
    }

    public void setOrders(ArrayList<OrderItem> orders) {
        this.order = orders;
    }

    public OrderItem addOrderItem() {
        OrderItem oi = new OrderItem();
        order.add(oi);
        return oi;
    }

    public void removeOrderItem(OrderItem oi) {
        order.remove(oi);
    }

    public OrderItem modifyOrderItem(OrderItem oi, int a) {
        int c = a;
        oi.setQuantity(c);
        return oi;
    }
}
