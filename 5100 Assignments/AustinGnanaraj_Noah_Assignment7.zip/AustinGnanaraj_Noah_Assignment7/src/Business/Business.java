/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Order.MasterOrderCatalog;
import Business.Organization.CustomerOrganization;
import Business.Organization.OrganizationDirectory;
import Business.Organization.SupplierOrganization;

/**
 *
 * @author AustinGnanaraj
 */
public class Business {

    private static Business business;
    private static SupplierOrganization supplierOrganization;
    private static CustomerOrganization customerOrganization;
    private MasterOrderCatalog masterOrderCatalog;

    private OrganizationDirectory organizationDirectory;

    private Business() {

        masterOrderCatalog = new MasterOrderCatalog();
        organizationDirectory = new OrganizationDirectory();
    }

    public static Business getInstance() {
        if (business == null) {
            business = new Business();
        }
        if (supplierOrganization == null) {
            supplierOrganization = new SupplierOrganization();
            business.getOrganizationDirectory().getOrganizationList().add(supplierOrganization);
        }
        if (customerOrganization == null) {
            customerOrganization = new CustomerOrganization();
            business.getOrganizationDirectory().getOrganizationList().add(customerOrganization);
        }
        return business;

    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(OrganizationDirectory organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }

    public MasterOrderCatalog getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public void setMasterOrderCatalog(MasterOrderCatalog masterOrderCatalog) {
        this.masterOrderCatalog = masterOrderCatalog;
    }

}
