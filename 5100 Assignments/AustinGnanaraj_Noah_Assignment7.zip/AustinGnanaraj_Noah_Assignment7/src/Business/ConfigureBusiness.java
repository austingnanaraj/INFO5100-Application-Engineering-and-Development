/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Person.Person;
import Business.Organization.AdminOrganization;
import Business.Roles.AdminRole;
import Business.User.UserAccount;

/**
 *
 * @author AustinGnanaraj
 */
public class ConfigureBusiness {

    public static Business configureBusiness() {
        Business business;
        AdminOrganization aor;
        Person per;
        business = Business.getInstance();
        UserAccount userAccount;
        per = new Person();
        aor = new AdminOrganization();
        userAccount = new UserAccount();
        per.setName("Austin");
        aor.personArrayList.add(per);
        userAccount.setRole(new AdminRole());
        userAccount.setUserName("admin");
        userAccount.setPassword("admin");
        userAccount.setStatus("Active");
        business.getOrganizationDirectory().getOrganizationList().add(aor);
        aor.userAccountArrayList.add(userAccount);
        return business;
    }
}
