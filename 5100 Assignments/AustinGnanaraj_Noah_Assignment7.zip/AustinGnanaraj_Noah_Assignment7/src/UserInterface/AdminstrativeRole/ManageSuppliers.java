package UserInterface.AdminstrativeRole;

import Business.Organization.Organization;
import Business.Organization.OrganizationDirectory;
import Business.Person.Person;
import Business.Supplier.Supplier;
import UserInterface.SupplierRole.AddSupplier;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

public class ManageSuppliers extends javax.swing.JPanel {

    private Supplier supplier;
    private JPanel userProcessContainer;
    private Organization organization;
    private OrganizationDirectory organizationDirectory;
    private Person person;

    public ManageSuppliers(JPanel userProcessContainer, OrganizationDirectory organizationDirectory) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.organizationDirectory = organizationDirectory;
        for (Organization o : organizationDirectory.getOrganizationList()) {
            if (o.getName() == "Supplier Organization") {
                this.organization = o;
                for (Person p : o.getPersonArrayList()) {
                    Supplier s = p.getSupplier();
                    this.supplier = s;
                }
            }
        }
        populateSupplerTable();
    }

    private void populateSupplerTable() {
        DefaultTableModel model = (DefaultTableModel) supplierTable.getModel();
        model.setRowCount(0);
        for (Person p : organization.getPersonArrayList()) {
            Supplier s = p.getSupplier();
            Object row[] = new Object[6];
            row[0] = s;
            row[1] = s.getAddress();
            row[2] = s.getState();
            row[3] = s.getZipcode();
            row[4] = s.geteMail();
            model.addRow(row);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        supplierTable = new javax.swing.JTable();
        btnRefresh = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnRemove = new javax.swing.JButton();
        btnView = new javax.swing.JButton();
        btnCreateSupplier = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        supplierTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Supplier Name", "Address", "State", "ZipCode", "E-Mail"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(supplierTable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 803, 97));

        btnRefresh.setText("Refresh");
        btnRefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRefreshActionPerformed(evt);
            }
        });
        add(btnRefresh, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 26, -1, -1));

        btnBack.setText("<<Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(116, 213, -1, -1));

        btnRemove.setText("Remove Supplier");
        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoveActionPerformed(evt);
            }
        });
        add(btnRemove, new org.netbeans.lib.awtextra.AbsoluteConstraints(268, 213, -1, -1));

        btnView.setText("View/Update Supplier >>");
        btnView.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewActionPerformed(evt);
            }
        });
        add(btnView, new org.netbeans.lib.awtextra.AbsoluteConstraints(484, 213, -1, -1));

        btnCreateSupplier.setText("Create Supplier>>");
        btnCreateSupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateSupplierActionPerformed(evt);
            }
        });
        add(btnCreateSupplier, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 285, 138, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        populateSupplerTable();
    }//GEN-LAST:event_btnRefreshActionPerformed

    private void btnViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewActionPerformed
        int selectedRow = supplierTable.getSelectedRow();
        if (selectedRow >= 0) {

            Supplier s = (Supplier) supplierTable.getValueAt(selectedRow, 0);

            ViewSupplier viewSupplier = new ViewSupplier(userProcessContainer, s);
            userProcessContainer.add("viewSupplier", viewSupplier);
            CardLayout layout = (CardLayout) userProcessContainer.getLayout();
            layout.next(userProcessContainer);
        } else {
            JOptionPane.showMessageDialog(null, "<<Please select a row>>");
        }
    }//GEN-LAST:event_btnViewActionPerformed

    private void btnRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoveActionPerformed
        int selectedrow = supplierTable.getSelectedRow();
        if (selectedrow >= 0) {
            int option = JOptionPane.showConfirmDialog(null, "Are you sure to"
                    + " remove?", "warning", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Supplier se = (Supplier) supplierTable.getValueAt(selectedrow, 0);

                for (Person per : organization.getPersonArrayList()) {
                    if (se.getName().equals(per.getName())) {
                        organization.getPersonArrayList().remove(per);
                        break;
                    }
                }
                
                populateSupplerTable();
            }
        } else {
            JOptionPane.showMessageDialog(null, "<<Please select a row>>");
        }

    }//GEN-LAST:event_btnRemoveActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnCreateSupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateSupplierActionPerformed
        AddSupplier supplierRegistrationFormJPanel = new AddSupplier(userProcessContainer, organizationDirectory);
        userProcessContainer.add("createSupplier", supplierRegistrationFormJPanel);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.next(userProcessContainer);
    }//GEN-LAST:event_btnCreateSupplierActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnCreateSupplier;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnRemove;
    private javax.swing.JButton btnView;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable supplierTable;
    // End of variables declaration//GEN-END:variables

}
