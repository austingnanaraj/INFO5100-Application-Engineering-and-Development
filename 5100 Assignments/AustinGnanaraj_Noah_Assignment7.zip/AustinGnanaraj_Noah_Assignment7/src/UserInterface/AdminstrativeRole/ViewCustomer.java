package UserInterface.AdminstrativeRole;

import Business.Customer.Customer;
import java.awt.CardLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ViewCustomer extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private Customer customer;

    public ViewCustomer(JPanel userProcessContainer, Customer customer) {
        initComponents();
        this.customer = customer;
        this.userProcessContainer = userProcessContainer;
        supplierName.setText(customer.getName());
        txtAddress.setText(customer.getAddress());
        txtEMail.setText(customer.geteMail());
        txtState.setText(customer.getState());
        txtSupplierName.setText(customer.getName());
        txtZipCode.setText(String.valueOf(customer.getZipCode()));

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        supplierName = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        txtSupplierName = new javax.swing.JTextField();
        txtAddress = new javax.swing.JTextField();
        txtState = new javax.swing.JTextField();
        txtZipCode = new javax.swing.JTextField();
        txtEMail = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();

        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        supplierName.setText("jLabel1");
        add(supplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 32, -1, -1));

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(359, 355, 130, 53));

        txtSupplierName.setEditable(false);
        add(txtSupplierName, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 89, 130, 33));

        txtAddress.setEditable(false);
        add(txtAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 133, 130, 36));

        txtState.setEditable(false);
        add(txtState, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 187, 130, 33));

        txtZipCode.setEditable(false);
        add(txtZipCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 238, 130, 36));

        txtEMail.setEditable(false);
        add(txtEMail, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 292, 130, -1));

        jLabel1.setText("Supplier Name");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 89, 106, 33));

        jLabel2.setText("Address");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 133, 106, 36));

        jLabel3.setText("State");
        add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 187, 106, 33));

        jLabel4.setText("ZipCode");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 238, 106, 36));

        jLabel5.setText("E-Mail");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 292, 114, 20));

        btnUpdate.setText("Update Supplier Details");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 339, 262, 39));

        btnSave.setText("Save Supplier Details");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 396, 262, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        userProcessContainer.remove(this);
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
        JOptionPane.showMessageDialog(null, "Please press the refresh button");
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        txtAddress.setEditable(true);
        txtEMail.setEditable(true);
        txtState.setEditable(true);
        txtSupplierName.setEditable(true);
        txtZipCode.setEditable(true);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        customer.setAddress(txtAddress.getText());
        customer.setName(txtSupplierName.getText());
        customer.setState(txtState.getText());
        customer.setZipCode(Integer.parseInt(txtZipCode.getText()));
        customer.seteMail(txtEMail.getText());
        JOptionPane.showMessageDialog(null, "Supplier Details Saved");
        txtAddress.setEditable(false);
        txtEMail.setEditable(false);
        txtState.setEditable(false);
        txtSupplierName.setEditable(false);
        txtZipCode.setEditable(false);
    }//GEN-LAST:event_btnSaveActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel supplierName;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JTextField txtEMail;
    private javax.swing.JTextField txtState;
    private javax.swing.JTextField txtSupplierName;
    private javax.swing.JTextField txtZipCode;
    // End of variables declaration//GEN-END:variables
}
